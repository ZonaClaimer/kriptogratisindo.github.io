/*
Template Name: Skote - Responsive Bootstrap 4 Admin Dashboard
Author: Themesbrand
Version: 1.4.0
Website: https://themesbrand.com/
Contact: themesbrand@gmail.com
File: Crypto KYC applicatiion Js File
*/

$(document).ready(function() {
    $('#kyc-verify-wizard').bootstrapWizard({
        'tabClass': 'nav nav-pills nav-justified'
    });
});