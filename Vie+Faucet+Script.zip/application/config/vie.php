<?php
// dont change license as this key is nulled
$licenseKey = 'Nulled by https://t.me/@ProTheme24x7';
// faucet url
$baseUrl = 'https://protheme24x7.eu.org/';
// database credential
$hostname = 'localhost';
$database = 'dbdatabase';
$username = 'dbusername';
$password = 'dbpassword';
// random string
$encryptionKey = 'CgdtIiGBaOdPG7ChK5An0Kf80pT9QO';