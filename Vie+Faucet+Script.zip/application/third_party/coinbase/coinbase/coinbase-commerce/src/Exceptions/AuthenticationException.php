<?php
namespace CoinbaseCommerce\Exceptions;

class AuthenticationException extends ApiException
{
}
