<?php
namespace CoinbaseCommerce\Exceptions;

class InternalServerException extends ApiException
{
}
